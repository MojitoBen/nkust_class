package com.example.hotpot;

public class StaticClass {
    static int Ppl; //人數
    static String Like;
    static String[][] QuestionArr = new String[8][8];
    static Boolean[][] AnswerRecord = new Boolean[8][8];
    static Integer[][] OrderRecord = new Integer[8][8];
    static int IngredientsPage = 0; //食材頁數
}
