package com.example.hotpot;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import com.asus.robotframework.API.RobotAPI;
import com.asus.robotframework.API.RobotCallback;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(this, BasicCheck.class); //設定意圖
        Button Btn = findViewById(R.id.button);

        Btn.setOnClickListener(view -> {
            startActivity(intent);
        });
    }
    protected void onResume() {
        super.onResume();
        //引用機器人的API與CALLBACK
        RobotCallback robotCallback = new RobotCallback();
        RobotAPI robotAPI = new RobotAPI(getApplicationContext(), robotCallback);
        robotAPI.robot.stopSpeak();
        robotAPI.robot.speak("準備吃鍋嚕~");
    }
}