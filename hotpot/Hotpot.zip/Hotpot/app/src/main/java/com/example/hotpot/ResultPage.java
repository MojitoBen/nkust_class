package com.example.hotpot;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ResultPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_page);

        TextView IngredientsTV = findViewById(R.id.textView16);
        TextView TotalMoney = findViewById(R.id.textView17);
        Button ReturnBtn = findViewById(R.id.button7);

        String[][] QuestionArr = StaticClass.QuestionArr;
        Boolean[][] AnswerRecord = StaticClass.AnswerRecord;

        //走訪填答需求食材
        String ResultTxt = "";
        for (int i = 0;i <= 6; i++){
            for (int j = 0; j <= 6; j++){
                if (AnswerRecord[i][j]){
                    ResultTxt += QuestionArr[i][j] + "、";
                }
            }
        }

        if (ResultTxt != ""){
            ResultTxt = "您選擇的食材有：" + "\n" + ResultTxt.substring(0, ResultTxt.length() - 1) + "\n" + "，感謝點餐。";
        }else {
            ResultTxt = "您只想喝高湯嗎";
        }
        IngredientsTV.setText(ResultTxt);

        ReturnBtn.setOnClickListener(view -> {
            finish();
            StaticClass.IngredientsPage = 0;
        });


    }
}