package com.example.hotpot;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class BasicCheck extends AppCompatActivity {
    private int mYear, mMonth, mDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_check);

        Intent intent = new Intent(this, Ingredients.class); //設定意圖

        TextView dateText = findViewById(R.id.textView4);
        Button dateButton = findViewById(R.id.button2);
        Button Btn = findViewById(R.id.button3);

        Btn.setOnClickListener(view -> {
            startActivity(intent);
        });

            dateButton.setOnClickListener(v -> {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);
                new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        String format = "您設定的日期為:" + setDateFormat(year, month, day);
                        dateText.setText(format);
                    }

                    private String setDateFormat(int year, int month, int day) {
                        char[] monthOfYear;
                        return String.valueOf(year) + "-"
                                + String.valueOf(month + 1) + "-"
                                + String.valueOf(day);
                    }
                }, mYear, mMonth, mDay).show();
            });
    }
               ;
    }

