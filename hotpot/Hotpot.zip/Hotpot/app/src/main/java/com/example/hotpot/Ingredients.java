package com.example.hotpot;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.asus.robotframework.API.RobotAPI;
import com.asus.robotframework.API.RobotCallback;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;

public class Ingredients extends AppCompatActivity {

    private Boolean EditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingredients);

        //引用機器人的API與CALLBACK
        RobotCallback robotCallback = new RobotCallback();
        RobotAPI robotAPI = new RobotAPI(getApplicationContext(), robotCallback);

        AssetManager am = getAssets();
        try {
            InputStream is = am.open("hotpot.txt");
            //將InputStream放入InputStreamReader並放入緩衝區BufferedReader
            //可以每次讀取一部份內容並轉字串
            BufferedReader bfReader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            String Line; //整列的內容
            int LineCount = 0;

            //走訪所有列
            while ((Line = bfReader.readLine()) != null){
                String[] LineSplit = Line.split(",");//將整列的文字以逗號分割
                StaticClass.QuestionArr[ LineCount ] = LineSplit;
                StaticClass.AnswerRecord [ LineCount ] = new Boolean[]{false, false, false, false, false, false, false, false, false};
                LineCount ++;
            }
            bfReader.close();
            is.close();// 關閉InputStream
        } catch (IOException e) {
            e.printStackTrace();
        }

        TextView Title = findViewById(R.id.textView5);
        TextView OptionTxt1 = findViewById(R.id.textView7);
        TextView OptionTxt2 = findViewById(R.id.textView8);
        TextView OptionTxt3 = findViewById(R.id.textView9);
        TextView OptionTxt4 = findViewById(R.id.textView10);
        TextView OptionTxt5 = findViewById(R.id.textView11);
        TextView OptionTxt6 = findViewById(R.id.textView12);
        TextView OptionTxt7 = findViewById(R.id.textView13);
        TextView OptionTxt8 = findViewById(R.id.textView14);
        Button PreviousBtn = findViewById(R.id.button4);
        Button NextBtn = findViewById(R.id.button5);
        EditText OptionNum1 = findViewById(R.id.editTextNumberDecimal2);
        EditText OptionNum2 = findViewById(R.id.editTextNumberDecimal3);
        EditText OptionNum3 = findViewById(R.id.editTextNumberDecimal4);
        EditText OptionNum4 = findViewById(R.id.editTextNumberDecimal5);
        EditText OptionNum5 = findViewById(R.id.editTextNumberDecimal6);
        EditText OptionNum6 = findViewById(R.id.editTextNumberDecimal7);
        EditText OptionNum7 = findViewById(R.id.editTextNumberDecimal8);
        EditText OptionNum8 = findViewById(R.id.editTextNumberDecimal9);

        String[] FirstLine = StaticClass.QuestionArr[0];//初進頁面取得第一列資訊
        Title.setText(FirstLine[0]);
        OptionTxt1.setText(FirstLine[1]);
        OptionTxt2.setText(FirstLine[2]);
        OptionTxt3.setText(FirstLine[3]);
        OptionTxt4.setText(FirstLine[4]);
        OptionTxt5.setText(FirstLine[5]);
        OptionTxt6.setText(FirstLine[6]);
        OptionTxt7.setText(FirstLine[7]);
        OptionTxt8.setText(FirstLine[8]);

        NextBtn.setOnClickListener(view -> {
            if (StaticClass.IngredientsPage < 6){
                StaticClass.IngredientsPage++;
                int QPage = StaticClass.IngredientsPage;
                String[] QueLine = StaticClass.QuestionArr[QPage];
                Title.setText(QueLine[0]);
                OptionTxt1.setText(QueLine[1]);
                OptionTxt2.setText(QueLine[2]);
                OptionTxt3.setText(QueLine[3]);
                OptionTxt4.setText(QueLine[4]);
                OptionTxt5.setText(QueLine[5]);
                OptionTxt6.setText(QueLine[6]);
                OptionTxt7.setText(QueLine[7]);
                OptionTxt8.setText(QueLine[8]);

                if(QPage == 6){
                    NextBtn.setText("完成");
                }else {
                    OptionTxt8.setText(QueLine[8]);
                }

                /**Integer[][] OrderRecord = StaticClass.AnswerRecord[QPage];
                int[] Answer;
                final Editable text = OptionNum1.getText(Answer[0]);
                CheckBox2.setText(Answer[1]);
                CheckBox3.setText(Answer[2]);
                CheckBox4.setText(Answer[3]);
                CheckBox5.setText(Answer[4]);**/


            }else if (StaticClass.IngredientsPage == 6){
                Intent intent = new Intent(this, ResultPage.class);
                startActivity(intent);
                finish();
            }
        });
        PreviousBtn.setOnClickListener(view -> {
            if (StaticClass.IngredientsPage > 0) {
                StaticClass.IngredientsPage--;
                int QPage = StaticClass.IngredientsPage;
                String[] QueLine = StaticClass.QuestionArr[QPage];
                Title.setText(QueLine[0]);
                OptionTxt1.setText(QueLine[1]);
                OptionTxt2.setText(QueLine[2]);
                OptionTxt3.setText(QueLine[3]);
                OptionTxt4.setText(QueLine[4]);
                OptionTxt5.setText(QueLine[5]);
                OptionTxt6.setText(QueLine[6]);
                OptionTxt7.setText(QueLine[7]);
                OptionTxt8.setText(QueLine[8]);

                if (QPage != 6) {
                    NextBtn.setText("下一頁");
                }
                OptionTxt8.setText(QueLine[8]);

                /**Boolean[] Answer = StaticClass.AnswerRecord[QPage];
                CheckBox1.setChecked(Answer[0]);
                CheckBox2.setChecked(Answer[1]);
                CheckBox3.setChecked(Answer[2]);
                CheckBox4.setChecked(Answer[3]);
                CheckBox5.setChecked(Answer[4]);*/

            }
        });
        /**OptionNum1.getText(view -> {
            int QPage = StaticClass.IngredientsPage;//取得當下的食材頁數
            int number = Integer.parseInt(OptionNum1.getText().toString());;
            StaticClass.AnswerRecord[QPage][0] =;

        });*/





    }


}